const Doctor = require("../models/doctorModel");

// CREATE
const createDoctor = async (req, res) => {
  const doctor = await Doctor.create(req.body);
  res.json(doctor);
};

// GET
const getDoctors = async (req, res) => {
  const doctors = await Doctor.find();
  res.json(doctors);
};

module.exports = { createDoctor, getDoctors };