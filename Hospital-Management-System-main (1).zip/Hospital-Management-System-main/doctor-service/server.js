require("dotenv").config();

const express = require("express");
const cors = require("cors");
const connectDB = require("./config/db");

const app = express();

connectDB();

app.use(cors());
app.use(express.json());

app.use("/api/doctors", require("./routes/doctorRoutes"));

app.listen(process.env.PORT, () => {
  console.log("Doctor Service running on port 5003");
});