import { useEffect, useState } from "react";
import api from "../services/api";

function Patients() {
  const [patients, setPatients] = useState([]);

  useEffect(() => {
    api.get("/patients")
      .then((res) => {
        setPatients(res.data);
      })
      .catch((err) => {
        console.error(err);
      });
  }, []);

  return (
    <div>
      <h2>Patients</h2>

      {patients.length === 0 ? (
        <p>No Patients</p>
      ) : (
        patients.map((p, i) => (
          <div key={i}>
            <p>{p.name}</p>
          </div>
        ))
      )}
    </div>
  );
}

export default Patients;