import axios from "axios";

export const patientAPI = axios.create({
  baseURL: "http://localhost:5002/api"
});

export const doctorAPI = axios.create({
  baseURL: "http://localhost:5003/api"
});

export const appointmentAPI = axios.create({
  baseURL: "http://localhost:5004/api"
});