import React, { useEffect, useState } from "react";
import "./App.css";

function App() {
  const doctors = [
    { name: "Dr. Kumar", specialization: "cardio" },
    { name: "Dr. Meena", specialization: "neuro" },
    { name: "Dr. Ravi", specialization: "ortho" },
    { name: "Dr. Priya", specialization: "general" },
    { name: "Dr. Arjun", specialization: "skin" },
    { name: "Dr. Neha", specialization: "ent" },
    { name: "Dr. Raj", specialization: "eye" },
    { name: "Dr. Anil", specialization: "diabetes" },
    { name: "Dr. Kavya", specialization: "child" }
  ];

  const [appointments, setAppointments] = useState([]);
  
  // ADDED 'condition' for abnormal signals
  const [patient, setPatient] = useState({
    id: "", name: "", age: "", village: "", disease: "", condition: "normal", gender: "Male"
  });

  const [matchedDoctor, setMatchedDoctor] = useState(null);
  const [date, setDate] = useState("");
  const [receipt, setReceipt] = useState(null);
  const [searchId, setSearchId] = useState("");
  const [result, setResult] = useState(null);

  // 🔄 LOAD FROM STORAGE
  useEffect(() => {
    const data = JSON.parse(localStorage.getItem("appointments")) || [];
    setAppointments(data);
  }, []);

  // 💾 SAVE TO STORAGE
  const saveToStorage = (data) => {
    localStorage.setItem("appointments", JSON.stringify(data));
  };

  // Generate Realistic Avatar based on Gender
  const getAvatar = (gender, seed) => {
    const randomId = Math.floor(Math.random() * 99);
    if (gender === 'Male') {
      return `https://randomuser.me/api/portraits/men/${randomId}.jpg`;
    } else if (gender === 'Female') {
      return `https://randomuser.me/api/portraits/women/${randomId}.jpg`;
    } else {
      // Transgender or other distinct realistic styled presentation
      return `https://api.dicebear.com/7.x/personas/svg?seed=${seed || Math.random()}&backgroundColor=e2e8f0`;
    }
  };

  // 🔍 SMART DOCTOR MATCHING
  const matchDoctor = () => {
    const d = patient.disease.toLowerCase();

    const mapping = {
      cardio: ["heart", "chest", "bp", "attack"],
      neuro: ["brain", "headache", "nerve", "stroke"],
      ortho: ["bone", "leg", "hand", "fracture", "pain"],
      skin: ["skin", "allergy", "rash", "burn"],
      ent: ["ear", "nose", "throat", "cough"],
      eye: ["eye", "vision", "blind"],
      diabetes: ["sugar", "diabetes", "insulin"],
      child: ["child", "baby", "kid"],
      general: []
    };

    let selectedSpecialist = "general";

    for (let key in mapping) {
      if (mapping[key].some(word => d.includes(word))) {
        selectedSpecialist = key;
        break;
      }
    }

    const doc = doctors.find(
      doc => doc.specialization.toLowerCase() === selectedSpecialist
    );

    setMatchedDoctor(doc || doctors[0]);
  };

  // 📅 BOOK APPOINTMENT
  const bookAppointment = () => {
    if (!patient.id || !patient.name || !date) {
      alert("Please fill all patient details and select a date.");
      return;
    }

    const busy = appointments.find(
      a => a.date === date && a.doctor.name === matchedDoctor.name
    );

    if (busy) {
      alert("Doctor is already fully engaged on this date ❌");
      return;
    }

    const day = new Date(date).toLocaleDateString("en-US", { weekday: "long" });

    const newApp = {
      patient: { ...patient, avatar: getAvatar(patient.gender, patient.name) },
      doctor: matchedDoctor,
      date,
      day,
      timestamp: new Date().getTime(),
      ticketNo: "TK-" + Math.floor(100000 + Math.random() * 900000)
    };

    const updated = [...appointments, newApp];

    setAppointments(updated);
    saveToStorage(updated);

    setReceipt(newApp);

    // reset
    setPatient({ id:"", name:"", age:"", village:"", disease:"", condition: "normal", gender: "Male" });
    setMatchedDoctor(null);
    setDate("");
    setSearchId("");
    setResult(null);
  };

  // Calculate doctor load on selected date
  const getDoctorLoad = (docName, targetDate) => {
    if(!targetDate || !docName) return 0;
    return appointments.filter(a => a.doctor.name === docName && a.date === targetDate).length;
  };

  // 🔍 SEARCH ANYTIME
  const searchPatient = () => {
    const data = JSON.parse(localStorage.getItem("appointments")) || [];
    const found = data.find(
      a => a.patient.id.toString() === searchId.toString()
    );

    if (!found) {
      alert("No patient record found for this ID ❌");
      setResult(null);
      return;
    }

    // Unify avatar check for old data compatibility
    if(!found.patient.avatar) found.patient.avatar = getAvatar(found.patient.gender || 'Male', found.patient.name);
    
    setResult(found);
    setReceipt(null); // hide receipt if searching
  };

  // DIGITAL TICKET COMPONENT
  const DigitalTicket = ({ data }) => (
    <div className="ticket-card">
      <div className="ticket-stamp">VERIFIED</div>
      <div className="ticket-header">
        <div>
          <h2 style={{ color: '#0f172a', margin:0, fontSize: '1.5rem' }}>E-Pass</h2>
          <span className="ticket-label">#{data.ticketNo || data.patient.id}</span>
        </div>
        <div style={{ textAlign: 'right' }}>
          <span className="ticket-label">Status</span>
          <br/>
          <span className={`badge ${data.patient.condition || 'normal'}`} style={{fontSize: '0.75rem', marginTop: '4px'}}>
            {data.patient.condition || 'Normal'}
          </span>
        </div>
      </div>
      
      <div className="ticket-divider"></div>

      <div className="ticket-body">
        <div className="patient-profile">
          <img src={data.patient.avatar} alt="Avatar" className="patient-avatar" style={{ objectFit: 'cover' }} />
          <div>
            <div className="ticket-value" style={{fontSize: '1.4rem'}}>{data.patient.name}</div>
            <div className="ticket-label">{data.patient.gender || 'Male'} • Age {data.patient.age} • {data.patient.village}</div>
          </div>
        </div>

        <div className="ticket-row" style={{ marginTop: '0.5rem' }}>
          <div>
            <div className="ticket-label">Condition</div>
            <div className="ticket-value" style={{textTransform:'capitalize'}}>{data.patient.disease}</div>
          </div>
          <div style={{ textAlign: 'right' }}>
            <div className="ticket-label">Patient ID</div>
            <div className="ticket-value">{data.patient.id}</div>
          </div>
        </div>

        <div style={{ padding: '1rem', background: '#f1f5f9', borderRadius: '12px', marginTop: '0.5rem' }}>
          <div className="ticket-row">
            <div>
              <div className="ticket-label">Attending Doctor</div>
              <div className="ticket-value" style={{color: '#4f46e5'}}>{data.doctor.name} ({data.doctor.specialization})</div>
            </div>
          </div>
          <div className="ticket-row" style={{marginTop: '0.5rem'}}>
            <div>
              <div className="ticket-label">Schedule Date</div>
              <div className="ticket-value">{data.date}</div>
            </div>
            <div style={{textAlign: 'right'}}>
              <div className="ticket-label">Day</div>
              <div className="ticket-value">{data.day}</div>
            </div>
          </div>
        </div>

        <div className="ticket-barcode"></div>
      </div>
    </div>
  );

  return (
    <div className="app-container">
      <header className="app-header">
        <h1>Hospital Management System</h1>
      </header>

      <div className="dashboard-grid">
        {/* PATIENT REGISTRATION CARD */}
        <div className={`glass-card ${patient.condition === 'critical' ? 'critical-state' : ''}`}>
          <div className="card-header">
            <div className="card-icon">🏥</div>
            <h2>Register Patient</h2>
          </div>

          {/* ABNORMAL TOGGLE */}
          <div className="input-group">
            <label>Severity Level</label>
            <div className="condition-toggle">
              <button 
                className={`condition-btn ${patient.condition === 'normal' ? 'active normal' : ''}`}
                onClick={() => setPatient({...patient, condition: 'normal'})}>
                Normal
              </button>
              <button 
                className={`condition-btn ${patient.condition === 'abnormal' ? 'active abnormal' : ''}`}
                onClick={() => setPatient({...patient, condition: 'abnormal'})}>
                Abnormal
              </button>
              <button 
                className={`condition-btn ${patient.condition === 'critical' ? 'active critical' : ''}`}
                onClick={() => setPatient({...patient, condition: 'critical'})}>
                Critical
              </button>
            </div>
          </div>

          <div className="input-group">
            <label>Patient ID</label>
            <input 
              className="premium-input" 
              placeholder="e.g. 101" 
              value={patient.id}
              onChange={e => setPatient({...patient,id:e.target.value})} 
            />
          </div>

          <div className="input-group">
            <label>Full Name</label>
            <input 
              className="premium-input" 
              placeholder="e.g. John Doe" 
              value={patient.name}
              onChange={e => setPatient({...patient,name:e.target.value})} 
            />
          </div>
          
          <div className="input-group">
            <label>Patient Gender</label>
            <div className="gender-toggle">
              <button 
                className={`gender-btn ${patient.gender === 'Male' ? 'active' : ''}`}
                onClick={() => setPatient({...patient, gender: 'Male'})}>
                Male
              </button>
              <button 
                className={`gender-btn ${patient.gender === 'Female' ? 'active' : ''}`}
                onClick={() => setPatient({...patient, gender: 'Female'})}>
                Female
              </button>
              <button 
                className={`gender-btn ${patient.gender === 'Transgender' ? 'active' : ''}`}
                onClick={() => setPatient({...patient, gender: 'Transgender'})}>
                Transgender
              </button>
            </div>
          </div>
          
          <div className="input-group">
            <label>Age</label>
            <input 
              className="premium-input" 
              placeholder="Age" 
              type="number"
              value={patient.age}
              onChange={e => setPatient({...patient,age:e.target.value})} 
            />
          </div>

          <div className="input-group">
            <label>City/Village</label>
            <input 
              className="premium-input" 
              placeholder="Location..." 
              value={patient.village}
              onChange={e => setPatient({...patient,village:e.target.value})} 
            />
          </div>

          <div className="input-group">
            <label>Symptoms / Disease</label>
            <input 
              className="premium-input" 
              placeholder="e.g. Severe chest pain" 
              value={patient.disease}
              onChange={e => setPatient({...patient,disease:e.target.value})} 
            />
          </div>

          <button onClick={matchDoctor} className={`premium-btn ${patient.condition === 'critical' ? 'btn-danger' : ''}`}>
            Find Doctor
          </button>
        </div>

        {/* DETAILS & ACTIONS COLUMN */}
        <div style={{ display: "flex", flexDirection: "column", gap: "2rem" }}>
          
          {/* SEARCH & DISPLAY TICKET */}
          {(receipt || result) && (
            <div style={{ animation: 'slideUp 0.5s ease' }}>
              <h3 style={{ marginBottom: '1rem', color: 'rgba(255,255,255,0.8)' }}>
                {receipt ? 'Booking Successfully Generated' : 'Found Patient Record'}
              </h3>
              <DigitalTicket data={receipt || result} />
              
              <button 
                onClick={() => { setReceipt(null); setResult(null); }} 
                className="premium-btn btn-secondary" 
                style={{ marginTop: '1rem', width: '100%' }}>
                Clear Ticket View
              </button>
            </div>
          )}

          {/* DOCTOR ALLOCATION & BOOKING SECTION */}
          {matchedDoctor && !receipt && (
            <div className="glass-card">
              <div className="card-header">
                <div className="card-icon">👨‍⚕️</div>
                <h2>Doctor Allocation</h2>
              </div>
              
              <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1rem' }}>
                <div className="doctor-avatar">🩺</div>
                <div>
                  <div style={{ fontSize: '1.25rem', fontWeight: '700' }}>{matchedDoctor.name}</div>
                  <span className="badge">{matchedDoctor.specialization} specialist</span>
                </div>
              </div>

              {date && (
                <div className="doctor-notify-panel">
                  <div>
                    <div style={{color: '#059669', fontSize: '0.85rem', fontWeight: 'bold', textTransform: 'uppercase'}}>Daily Patient Load</div>
                    <div style={{color: '#0f172a', fontWeight: '500'}}>{new Date(date).toLocaleDateString()}</div>
                  </div>
                  <div className="patient-count">
                    {getDoctorLoad(matchedDoctor.name, date)}
                  </div>
                </div>
              )}

              <div style={{ height: '1px', background: 'var(--surface-border)', margin: '1rem 0' }}></div>
              
              <div className="input-group">
                <label>Select Date for Appointment</label>
                <input 
                  type="date" 
                  className="premium-input"
                  value={date}
                  onChange={e => setDate(e.target.value)} 
                />
              </div>

              <button 
                onClick={bookAppointment} 
                className="premium-btn"
                style={{ marginTop: '0.5rem' }}>
                Confirm & Print Pass
              </button>
            </div>
          )}

          {/* PATIENT SEARCH BOX */}
          {!receipt && !result && (
            <div className="glass-card" style={{ flexGrow: 1, justifyContent: 'center' }}>
              <div className="card-header">
                <div className="card-icon">🔎</div>
                <h2>Database Lookup</h2>
              </div>
              <p className="subtitle" style={{ fontSize: '0.9rem', marginBottom: '0.5rem' }}>
                Retrieve generated digital e-passes.
              </p>

              <div className="input-group">
                <input 
                  className="premium-input"
                  placeholder="Enter Patient ID" 
                  value={searchId}
                  onChange={e => setSearchId(e.target.value)} 
                />
              </div>
              
              <button onClick={searchPatient} className="premium-btn btn-secondary">
                Search Records
              </button>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}

export default App;