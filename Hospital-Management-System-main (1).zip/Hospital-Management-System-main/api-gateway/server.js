const express = require("express");
const cors = require("cors");
const { createProxyMiddleware } = require("http-proxy-middleware");

const app = express();
app.use(cors());

// ✅ Home route (to avoid "Cannot GET /")
app.get("/", (req, res) => {
  res.send("API Gateway Working 🚀");
});

// ✅ Patients → 5002
app.use("/api/patients", createProxyMiddleware({
  target: "http://localhost:5002",
  changeOrigin: true
}));

// ✅ Doctors → 5003
app.use("/api/doctors", createProxyMiddleware({
  target: "http://localhost:5003",
  changeOrigin: true
}));

// ✅ Appointments → 5004
app.use("/api/appointments", createProxyMiddleware({
  target: "http://localhost:5004",
  changeOrigin: true
}));

app.listen(5000, () => {
  console.log("Gateway running on port 5000");
});