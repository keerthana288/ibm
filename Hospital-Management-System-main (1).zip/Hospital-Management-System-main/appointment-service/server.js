require("dotenv").config();

const express = require("express");
const cors = require("cors");
const connectDB = require("./config/db");

const app = express();

connectDB();

app.use(cors());
app.use(express.json());

app.use("/api/appointments", require("./routes/appointmentRoutes"));

app.listen(process.env.PORT, () => {
  console.log("Appointment Service running on port 5004");
});