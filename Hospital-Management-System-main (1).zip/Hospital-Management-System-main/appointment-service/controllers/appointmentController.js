const Appointment = require("../models/appointmentModel");

// CREATE
const createAppointment = async (req, res) => {
  const appointment = await Appointment.create(req.body);
  res.json(appointment);
};

// GET
const getAppointments = async (req, res) => {
  const data = await Appointment.find();
  res.json(data);
};

module.exports = { createAppointment, getAppointments };