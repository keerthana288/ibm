const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

// ✅ IMPORTANT → /api/patients
app.get("/api/patients", (req, res) => {
  res.json([{ name: "Rahul" }]);
});

app.post("/api/patients", (req, res) => {
  res.json({ message: "Patient added" });
});

app.listen(5002, () => {
  console.log("Patient Service running on 5002");
});